package es.ifp.programacion.uf3.actividadpractica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * El ejercicio evaluable se compone de un ejercicio único con varias subproblemas a resolver.  
 * Una empresa dedicada al desarrollo de software necesita hacer un pequeño 
 * programa en Java que se va a ejecutar en un sistema Linux. 
 * 
 * El programa no tendrá interfaz gráfico, sino que será a través 
 * de la consola Linux donde se introducirá la información necesaria 
 * para la correcta ejecución del mismo. El programa gestionará información 
 * en un fichero de texto donde se van a introducir datos personales. 
 * 
 * Estos datos son: nombre, apellidos y correo electrónico. 
 * Los datos para cada usuario se escribirán en una línea separados 
 * entre ellos por el carácter ‘;’ 
 * 
 * 1.- El programa mostrará un menú con las siguientes opciones: 
 * A) Crear fichero de texto. 
 * B) Introducir información en el fichero. 
 * C) Leer el fichero de texto. 
 * D) Eliminar el fichero de texto. 
 * E) Salir  
 * 
 * 2.- Si el fichero no está creado, se creará adecuadamente. 
 * Todos los ficheros se crearán en una subcarpeta 
 * denominada: usuarios que estará ubicada dentro del proyecto de Eclipse 
 * 3.- El usuario accederá a las opciones de menú a través de la 
 * letra mayúsculas que precede el texto del menú: (A, B, C, D, E). 
 * 4.- Deberán desarrollarse las validaciones y comprobaciones que considere 
 * pertinentes el alumno para un sencillo y correcto funcionamiento del programa. 
 *  5.- Finalmente, si el usuario ya ha creado un fichero, 
 *  la siguiente vez que se muestre el menú se deberá mostrar al usuario, 
 *  a modo informativo, la ruta en la que se encuentra el último fichero creado 
 *  Por ejemplo: 
 *  - Un usuario accede a la opción A y crea un fichero en la ruta: “usuarios/ficheros” 
 *  llamado usuarios.txt. 
 *  Por tanto, la ruta absoluta de este fichero es: “usuarios/ficheros/usuarios.txt” 
 *  - Una vez creado este fichero, la siguiente vez que se muestre el menú 
 *  aparecerá en la última línea:  
 *  “Fichero creado por última vez: /usuarios/ficheros/usuarios.txt” 
 *  6.- El menú se mostrará repetidamente hasta que el usuario salga del programa.
 *  7.- Antes de borrar un fichero deberá mostrarse un mensaje de confirmación del borrado.
 *  8.- Adjunta la documentación en formato Javadoc 
 *  
 *  Solución:
 *  La solución planteada en este ejercicio es almacenar la ruta del último archivo creado
 *  en un fichero interno de la aplicación (llamémosle fichero de configuración)
 *  
 *  Cuando se muestre el menú, en la parte en la que hay que mostrar esta información, iremos a 
 *  buscar si hay alguna ruta almacenada en el fichero de configuración. Si hay ruta, la extraemos del 
 *  fichero de configuración y la mostramos en el menú. Si no hay ruta, indica que no se ha creado aún
 *  ningún fichero con la opción A y no se muestra esta información en el menú.
 *  
 *  Cuando se cree un fichero, una vez creado, se guarda la ruta en el fichero de configuración,
 *  sobrescribiendo lo que ya existe. Esto solo se programará en la opción de crear fichero.
 *  
 *  
 * @author juan
 *
 */
public class ProgramaPrincipal {

	public static void main(String[] args) {
		String opcion;
		Scanner sc = new Scanner(System.in);
		final String iniFichName = "config.ini";
		do {
			muestraMenu(iniFichName);
			opcion = sc.nextLine();
			switch(opcion) {
			case "A": 
				crearFichero(iniFichName);
				break;
			case "B":
				escribirFichero();
				break;
			case "C":
				leerFichero();
				break;
			case "D":
				eliminarFichero();
				break;
			case "E":
				break;
			default:
				System.out.println("Opción incorrecta.");
			}
		}while(!opcion.equals("E"));
		System.out.println("Fin de la ejecución del programa.");
	}
	
	
	/**
	 * Procedimiento que crea un fichero bajo el directorio usuarios
	 * Todos los datos se solicitan dentro de este procedimiento
	 * Se implementa validaciones para comprobar que el fichero existe.
	 * 
	 * Si se crea el fichero por primera vez, también creamos el directorio usuarios.
	 * @param iniFichName Nombre del fichero de configuración
	 */
	public static void crearFichero(String iniFichName) {
		Scanner sc = new Scanner(System.in);
		File f = null;
		File dir = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		String ruta;
		
		System.out.println("Introduzca el nombre del fichero a crear:");
		ruta = sc.nextLine();
		
		f = new File("usuarios/"+ruta);
		if (f.exists()) {
			System.out.println("El fichero ya existe.");
		}else {
		  
		  try {
			
			dir = new File("usuarios/");
			dir.mkdir();
			
			//Crear el fichero
			f.createNewFile();
			System.out.println("Fichero creado correctamente");
			
			//Escribimos en el fichero de configuración la ruta del fichero creado.
			f = new File(iniFichName);
			fw = new FileWriter(f);
			bw = new BufferedWriter(fw);
			bw.write(ruta);
		  }
		  catch(IOException ioe) {
			  System.out.println("Error al crear el fichero.");
			  ioe.printStackTrace();
		  }
		  finally {
			  try {
				  bw.close();
				  fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		}
	}
	
	/**
	 * Procedimiento que escribe en un fichero una cadena con separadores ;
	 * El fichero a escribir y la cadena serán solicitados dentro de este procedimiento.
	 */
	public static void escribirFichero() {
		File f = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		Scanner sc = new Scanner(System.in);
		String ruta, nombre, apellidos, correo, linea;
		
		System.out.println("Introduzca la ruta y nombre del fichero a escribir:");
		ruta = sc.nextLine();
		f = new File(ruta);
		if (f.exists()) {
			System.out.println("Introduzca el nombre:");
			nombre = sc.nextLine();
			System.out.println("Introduzca apellidos:");
			apellidos = sc.nextLine();
			System.out.println("Introduzca el correo:");
			correo = sc.nextLine();
			linea = nombre+";"+apellidos+";"+correo;
			try {
				fw = new FileWriter(f);
				bw = new BufferedWriter(fw);
				bw.write(linea);
			}
			catch(IOException ioe) {
				ioe.printStackTrace();
			}
			finally {
				try {
					bw.close();
					fw.close();
				}
				catch(IOException io) {
					io.printStackTrace();
				}
			}
		}
		else {
			System.out.println("El fichero no existe, debe crearlo primero.");
			
		}
		
	}

	/**
	 * Procedimiento utilizado para leer un fichero 
	 * El fichero se solicita al usuario
	 * Se mostrará en consola resultado
	 */
	public static void leerFichero() {
		Scanner sc = new Scanner(System.in);
		File f=null;
		FileReader fr=null;
		BufferedReader br = null;
		String linea;
		String totalLineas="";
		String ruta;
		
		System.out.println("Introduzca la ruta y el nombre del fichero a leer:");
		ruta = sc.nextLine();
		
		try {
			f = new File(ruta);
			if (f.exists()) {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				
				linea =br.readLine();
				while(linea!=null) {
					totalLineas+=linea+"\n";
					linea = br.readLine();
				}
				System.out.println("El contenido del fichero es:");
				System.out.println(totalLineas);
			}
			else 
				System.out.println("El fichero "+ruta+" no existe.");
			
		}
		catch(IOException ioe) {
			ioe.printStackTrace();
		}
		finally {
			try {
				br.close();
				fr.close();
			}
			catch(IOException io) {
				io.printStackTrace();
			}
		}
		
		
		
		
	}
	
	/**
	 * Borra un fichero indicado por el usuario.
	 * Se muestra un mensaje de confirmación de borrado.
	 */
	public static void eliminarFichero() {
		File f = null;
		Scanner sc = new Scanner(System.in);
		String ruta, opc;
		
		System.out.println("Introduzca la ruta y nombre del fichero a eliminar:");
		ruta = sc.nextLine();
		f = new File(ruta);
		if (f.exists()) {
			System.out.println("¿Desea borrar el fichero "+ruta+" ? (S/N):");
			opc = sc.nextLine();
			if (opc.equals("S")) {
				if (f.delete()) {
					System.out.println("El fichero "+ruta+" ha sido borrado correctamente.");
				}
				else
					System.out.println("El fichero no ha sido borrado:"+ruta);
			}
			else 
				System.out.println("Opción seleccionada (N): El fichero no se borrará.");
		}
		else {
			System.out.println("El fichero a borrar no existe:"+ruta);
		}
		
		
		
	}
	
	
	/**
	 * Procedimiento que muestra el menú de opciones al usuario
	 * @param iniFichName nombre del fichero de configuración donde se almacena
	 * la ruta del último fichero creado.
	 */
	public static void muestraMenu(String iniFichName) {
		
		String lastFile = getFichIni(iniFichName);
		
		System.out.println("=========================================");
		System.out.println("A) Crear fichero de texto");
		System.out.println("B) Introducir información en el fichero");
		System.out.println("C) Leer el fichero de textos");
		System.out.println("D) Eliminar un fichero de textos");
		System.out.println("E) Salir");
		
		if (lastFile!=null) {
			System.out.println("=========================================");
			System.out.println("Fichero creado por última vez:usuarios/"+lastFile);
		}
		
		System.out.println("=========================================");
		System.out.println("Introduzca la opción a ejecutar:");
	}
	
	
	/**
	 * Accede al fichero de configuración para conocer si hay último fichero
	 * con el que el usuario ha trabajado.
	 * @param iniFichName ruta del fichero configuración que almacenará el último 
	 * fichero creado
	 * @return null si no hay nada dentro del fichero (no hay ruta) o el valor almacenado
	 * dentro del fichero configuración.
	 */
	public static String getFichIni(String iniFichName) {
		File f = new File(iniFichName);
		FileReader fr = null;
		BufferedReader br = null;
		String lastFile=null;
		
		if (f.exists()) {
		  try {
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			lastFile=br.readLine();
		  }
		  catch(IOException ioe) {
			  ioe.printStackTrace();
		  }
		}
		return lastFile;
		
		
		
		
	}
	
	
	
	
	
	
	
	
	

}
