package es.ifp.programacion.ejercicio.retouf4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Definición de objetos
		Usuario usuario1 = new Usuario("Antonio", "Vega Vega", "12345678A");
		Usuario usuario2 = new Usuario("María", "López López", "99887766B", "correoUsuario2@correo.es", "654332211");
		
		//Definición de la estructura de datos
		HashMap<String, Usuario> hashMap = new HashMap<String, Usuario>();
		
		//Añado objetos a la estructura
		hashMap.put(usuario1.getDNI(), usuario1);
		hashMap.put(usuario2.getDNI(), usuario2);
		
		//Recorrer la estructura de datos
		//En un conjunto almaceno las claves del hashMap
		Set<String>setKeys = hashMap.keySet();
		Iterator<String> itKeys = setKeys.iterator();
		
		Usuario tmpUser;
		String tmp;
		while (itKeys.hasNext()) {
			tmp = itKeys.next();
			tmpUser = hashMap.get(tmp);
			System.out.println(tmpUser.toString());
		}
		
		

	}

}
