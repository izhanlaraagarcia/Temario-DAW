package es.ifp.programacion.ejercicio.retouf4;

public class Usuario {
	
	
	private String nombre;
	private String apellidos;
	private String DNI;
	private String correoElectronico;
	private String telefono;
	
	
	public Usuario(String nombre, String apellidos, String dni, String correoElectronico, String telefono) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.DNI=dni;
		this.correoElectronico=correoElectronico;
		this.telefono=telefono;
	}
	
	public Usuario(String nombre, String apellidos, String DNI) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.DNI=DNI;
		this.correoElectronico="No tiene.";
		this.telefono="No tiene.";
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the dNI
	 */
	public String getDNI() {
		return DNI;
	}

	/**
	 * @param dNI the dNI to set
	 */
	public void setDNI(String dNI) {
		DNI = dNI;
	}

	/**
	 * @return the correoElectronico
	 */
	public String getCorreoElectronico() {
		return correoElectronico;
	}

	/**
	 * @param correoElectronico the correoElectronico to set
	 */
	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	/**
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}

	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	@Override
	public String toString() {
		return "==========================\n"+
				"USUARIO:"+
				"\nNombre:"+this.getNombre()+
				"\nApellidos:"+this.getApellidos()+
				"\nDNI:"+this.getDNI()+
				"\nCorreo:"+this.getCorreoElectronico()+
				"\nTeléfono:"+this.getTelefono()+
				"\n=========================";	
	}
	
	
	
	

}
