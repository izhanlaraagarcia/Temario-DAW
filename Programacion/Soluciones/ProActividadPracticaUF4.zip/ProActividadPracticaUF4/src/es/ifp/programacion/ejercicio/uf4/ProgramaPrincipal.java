package es.ifp.programacion.ejercicio.uf4;

import java.util.Date;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cliente cliente = new Cliente("Andrés", "Gómez", "Lara", "12345678A", "ID23");
		JefeProyecto jp = new JefeProyecto("Juan Pedro", "Marrero", "Tarriño", "98765432B",5);
		
		Proyecto prj = new Proyecto("PRJ1001", "BOG", "Broker Online BA", new Date(), cliente, jp);
		
		
		System.out.println(prj.toString());
		
	}

}
