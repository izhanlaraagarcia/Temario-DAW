package es.ifp.programacion.ejercicio.uf4;

/**
 * Clase Cliente que hereda de Persona
 * Tiene un atributo específico que es el identificador de cliente
 * Sobrescribimos el método toString
 * Implementamos el método getRol
 * @author juan
 *
 */
public class Cliente extends Persona{
	
	private String idCliente;
	private static final String rol="CLI";
	
	public Cliente(String nombre, String ape1, String ape2, String dni, String idCliente) {
		super(nombre, ape1, ape2, dni);
		this.setIdCliente(idCliente);
	}

	/**
	 * @return the idCliente
	 */
	public String getIdCliente() {
		return idCliente;
	}

	/**
	 * @param idCliente the idCliente to set
	 */
	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}
	
	/**
	 * Implementación del método abstracto
	 * @return un String con el rol del JP (definido como constante)
	 */
	public String getRol() {
		return this.rol;
	}
	

	@Override
	/**
	 * Sobreescribimos el método toString
	 * Retorna todos los datos del cliente
	 */
	public String toString() {
		return super.toString()+"\n"+
			   "Identificador de cliente:"+this.getIdCliente();				
	}
	
	
	
	
	
	
	

}
