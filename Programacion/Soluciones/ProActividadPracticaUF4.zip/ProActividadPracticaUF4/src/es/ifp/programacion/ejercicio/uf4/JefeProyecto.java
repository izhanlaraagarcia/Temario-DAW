package es.ifp.programacion.ejercicio.uf4;


/**
 * Clase JefeProyecto que hereda de Persona
 * Tiene un atributo específico que es el número de empleado
 * Sobrescribimos el método toString
 * Implementamos el método getRol
 * @author juan
 *
 */
public class JefeProyecto extends Persona{
	
	private int numEmpleado;
	private final static String rol="JP";
	
	public JefeProyecto (String nombre, String ape1, String ape2, String dni, int numEmpleado){
		super(nombre, ape1, ape2, dni);
		this.setNumEmpleado(numEmpleado);
	}
	
	
	
	
	/**
	 * @return the numEmpleado
	 */
	public int getNumEmpleado() {
		return numEmpleado;
	}




	/**
	 * @param numEmpleado the numEmpleado to set
	 */
	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}




	/**
	 * Implementación del método abstracto
	 * @return un String con el rol del JP (definido como constante)
	 */
	public String getRol() {
		return this.rol;
	}
	
	
	
	@Override
	/**
	 * Sobreescribimos el método toString
	 * Retorna todos los datos del JP
	 */
	public String toString() {
		return super.toString()+"\n"+
			   "Número de empleado:"+this.getNumEmpleado();				
	}
}
