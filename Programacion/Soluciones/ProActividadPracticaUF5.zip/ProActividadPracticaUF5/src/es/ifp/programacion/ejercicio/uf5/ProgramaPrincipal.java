package es.ifp.programacion.ejercicio.uf5;

import java.util.Date;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cliente cliente = new Cliente("Andrés", "Gómez", "Lara", "12345678A", "ID23");
		JefeProyecto jp = new JefeProyecto("Juan Pedro", "Marrero", "Tarriño", "98765432B",5);
		
		Cliente cliente2 = new Cliente("Andrés2", "Gómez2", "Lara2", "22335577A", "ID24");
		JefeProyecto jp2 = new JefeProyecto("Juan2 Pedro2", "Marrero2", "Tarriño2", "99663322B",6);
		
		
		
		Proyecto prj = new Proyecto("PRJ1001", "BOG", "Broker Online BA", new Date(), cliente, jp);
		
		prj.addCliente(cliente2);
		prj.addJp(jp2);
		
		
		System.out.println(prj.toString());
		
	}

}
