package es.ifp.programacion.ejercicio.uf5;
/**
 * Clase persona de la que heredarán Jefe de proyecto y cliente
 * para reutilizar los atributos comunes
 * 
 * Clase abstracta para modela que el Jefe de proyecto y el cliente
 * implementen el método getRol que devolverá el rol de cada uno de ellos.
 * @author juan
 *
 */
public abstract class Persona {
	
	private String nombre;
	private String apellido1;
	private String apellido2;
	private String dni;
	
	/**
	 * Constructor con todos los parámetros tal y como
	 * se indica en el enunciado.
	 * @param nombre
	 * @param apellido1
	 * @param apellido2
	 * @param dni
	 */
	public Persona(String nombre, String apellido1, String apellido2, String dni) {
		this.nombre=nombre;
		this.apellido1=apellido1;
		this.apellido2=apellido2;
		this.dni=dni;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	
	/**
	 * @return the apellido1
	 */
	public String getApellido1() {
		return apellido1;
	}

	
	/**
	 * @return the apellido2
	 */
	public String getApellido2() {
		return apellido2;
	}

	
	/**
	 * @return the dni
	 */
	public String getDni() {
		return dni;
	}
	
	
	@Override
	/**
	 * Sobreescribimos el método toString
	 * Retorna todos los datos del JP
	 */
	public String toString() {
		return "Nombre:"+this.getNombre()+"\n"+
			   "Apellidos:"+this.getApellido1()+" "+this.getApellido2()+"\n"+
			   "DNI:"+this.getDni()+"\n"+
			   "Rol:"+this.getRol();  
	}
	
	
	/**
	 * Método abstracto para modelar el rol de las clases hijas
	 * @return un String con el rol de la persona
	 */
	public abstract String getRol();

	
	

}
