package es.ifp.programacion.ejercicio.uf5;

import java.util.ArrayList;
import java.util.Date;
import java.util.ArrayList;


/**
 * Clase Proyecto que por composición
 * tiene un JP, un cliente y las características
 * propias del proyecto
 * 
 * @author juan
 *
 */
public class Proyecto {
	
	private ArrayList<Cliente> clientes;
	private ArrayList<JefeProyecto> jps;
	private String idProyecto;
	private String nombreProyecto;
	private String descProyecto;
	private Date fechaIni;
	
	/**
	 * 
	 * @param idProyecto
	 * @param nombreProyecto
	 * @param descProyecto
	 * @param fechaIni
	 * @param cliente
	 * @param jp
	 */
	public Proyecto(String idProyecto, String nombreProyecto, String descProyecto, Date fechaIni, Cliente cliente, JefeProyecto jp) {
		this.idProyecto=idProyecto;
		this.nombreProyecto=nombreProyecto;
		this.descProyecto=descProyecto;
		this.fechaIni=fechaIni;
		this.clientes = new ArrayList();
		this.addCliente(cliente);
		this.jps = new ArrayList();
		this.addJp(jp);
	}


	/**
	 * @return the cliente
	 */
	public ArrayList<Cliente> getClientes() {
		return clientes;
	}


	/**
	 * @param cliente the cliente to set
	 */
	public void addCliente(Cliente cliente) {
		this.clientes.add(cliente);
	}


	/**
	 * @return the jp
	 */
	public ArrayList<JefeProyecto> getJps() {
		return jps;
	}


	/**
	 * @param jp the jp to set
	 */
	public void addJp(JefeProyecto jp) {
		this.jps.add(jp);
	}


	/**
	 * @return the idProyecto
	 */
	public String getIdProyecto() {
		return idProyecto;
	}


	/**
	 * @param idProyecto the idProyecto to set
	 */
	public void setIdProyecto(String idProyecto) {
		this.idProyecto = idProyecto;
	}


	/**
	 * @return the nombreProyecto
	 */
	public String getNombreProyecto() {
		return nombreProyecto;
	}


	/**
	 * @param nombreProyecto the nombreProyecto to set
	 */
	public void setNombreProyecto(String nombreProyecto) {
		this.nombreProyecto = nombreProyecto;
	}


	/**
	 * @return the descProyecto
	 */
	public String getDescProyecto() {
		return descProyecto;
	}


	/**
	 * @param descProyecto the descProyecto to set
	 */
	public void setDescProyecto(String descProyecto) {
		this.descProyecto = descProyecto;
	}


	/**
	 * @return the fechaIni
	 */
	public Date getFechaIni() {
		return fechaIni;
	}


	/**
	 * @param fechaIni the fechaIni to set
	 */
	public void setFechaIni(Date fechaIni) {
		this.fechaIni = fechaIni;
	}
	
	
	/**
	 * Sobrescribimos el método toString
	 * Recorremos con un bucle for los dos ArrayList
	 * para imprimir cada cliente y jp que hay en las
	 * estructuras respectivas.
	 */
	@Override
	public String toString() {
		
		int nClientes=this.getClientes().size();
		Cliente cli;
		int nJPs=this.getJps().size();
		JefeProyecto jp;
		String resultado;
		resultado=
			   "==================================\n"+
			   "          DATOS PROYECTO          \n"+
			   "==================================\n"+
			   "Nombre proyecto:"+this.getNombreProyecto()+"\n"+
			   "Id. proyecto:"+this.getIdProyecto()+"\n"+
			   "Descripción:"+this.getDescProyecto()+"\n"+
			   "Fecha de inicio:"+this.getFechaIni()+"\n"+
			   "==================================\n"+
			   "          DATOS CLIENTES          \n"+
			   "==================================\n";
			   for (int i=0;i<nClientes;i++) {
				   cli = this.getClientes().get(i);
				   resultado+="\n"+cli.toString();
				   resultado+="\n__________________________________\n";
			   }
			   
			   resultado +=
			   "==================================\n"+
			   "             DATOS JPS            \n"+
			   "==================================\n";
			   
			   for (int i=0;i<nJPs;i++) {
				   jp = this.getJps().get(i);
				   resultado+="\n"+jp.toString();
				   resultado+="\n__________________________________\n";
			   }
			   
			 return resultado;
			   
			   
	}
	
	

}
