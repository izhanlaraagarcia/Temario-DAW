package es.ifp.programacion.uf3.reto;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 El ejercicio evaluable consistirá en realizar un programa que gestione flujos de Entrada/Salida en Java.  
 El programa mostrará el siguiente menú:  
 A) Crear fichero 
 B) Escribir en fichero de textos 
 C) Salir  
 
 Requisitos: 
 1.- Cualquier entrada de información de teclado deberá hacerse SIN utilizar la clase Scanner 
 y utilizando las clases de flujos que incorpora la librería estándar de Java. Explica la solución adoptada. (3 pt.) 
 2.- Si el usuario introduce la opción A: se pedirá nombre y ruta para crear el fichero, 
 haciendo las comprobaciones correspondientes para ver si existe o no. (1 pt.) 
 3.- Opción B: Se pedirá al usuario la frase-línea-palabra-cadena a insertar en el fichero. 
 Si el fichero no existe se mostrará el correspondiente aviso. (1 pt.) 
 4.- El menú se mostrará de forma indefinida hasta que se produzca la condición de salida, 
 que será cuando el usuario pulse el carácter ‘C’ o ‘c’. (1 pt.) 
 5.- Adjunta la documentación en javadoc al proyecto. (1 pt.) 
 * @author juan
 *
 */



public class ProgramaPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String opcion="";
		
		do {
			muestraMenu();
			//¿como recojo la opción que ha introducido el usuario después de mostrar el menú
			//Scanner sc = new Scanner(System.in);
			//System.out.println("Introduzca opción a ejecutar:");
			//opcion = sc.nextLine();
			
			opcion = getDataFromKeyboard("Introduzca la opción a ejecutar:");
			
			switch(opcion) {
				case "A":
					creaFichero();
					break;
				case "B":
					escribeFichero();
					break;
				case "C":
					break;
				default:
					System.out.println("La opción introducida es incorrecta.");
			}
		}
		while (!opcion.equals("C") && !opcion.equals("c"));
		System.out.println("Fin de la ejecución del programa.");
}
	
	
	public static void creaFichero() {
		String fichero="";
		boolean creado=false;
		
		//Aquí necesito mostrar un mensaje al usuario de la ruta con el fichero a crear
		//Y recoger la ruta
		//¿Cómo cojo la ruta del fichero para crearlo?
		
		fichero = getDataFromKeyboard("Introduzca el fichero a crear:");
		
		File f = new File(fichero);
		try {
			if (!f.exists()) {
				creado = f.createNewFile();
				if (creado)
					System.out.println("Creado el fichero "+fichero);
				else
					System.out.println("No ha sido posible crear el fichero "+fichero);
			}
			else
				System.out.println("El fichero "+fichero+" ya existe.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
	}
	
	/**
	 * Procedimiento que escribe en un fichero de textos.
	 * Se solicita al usuario toda la información para escribir en el fichero.
	 * Si no existe, se informa al usuario y se pregunta si desea crearlo.
	 */
	public static void escribeFichero() {
		String fichero="";
		String cadena="";
		String opc="";
		File f = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		
		//Aquí necesito mostrar un mensaje al usuario de la ruta con el fichero a escribir
		//Y recoger la ruta
		//¿Cómo cojo la ruta del fichero para escribir?
		//fichero = 
		
		fichero = getDataFromKeyboard("Introduzca el fichero a escribir:");
		
		
		
		
		try {
			f = new File(fichero);
				if (!f.exists()) {  //Si el fichero no existe planteamos la posibilidad de crearlo
					
					//Luego, si planteamos la opción de que cree el fichero en el caso que no exista,
					//¿Cómo cojo la opción para crearlo o no y asignarlo a opc?
					opc = getDataFromKeyboard("El fichero no existe, ¿desea crearlo? (S/N):");
					
					if (opc.equals("S")) {
						try {
							f.createNewFile();
							System.out.println("Creado el fichero "+fichero);
							cadena = "";
							fw = new FileWriter(f, true);  //true ya que siempre añadimos al final
							bw = new BufferedWriter(fw);
						
							while (!cadena.equals("EOF")) {
								
								cadena = getDataFromKeyboard("Introduzca la cadena a escribir (EOF para terminar):");
								//Aquí necesito coger la cadena para escribirla, pero ¿cómo sin utilizar Scanner?
								
								if (!cadena.equals("EOF"))
									bw.write(cadena+"\n");
								//Importante: Cerrar antes el BufferedWriter que el FileWriter
							}
							bw.close();
							fw.close();
							
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					else
						System.out.println("No se ha creado el fichero "+fichero);
			}
			else {
				cadena = "";
				fw = new FileWriter(f, true);  //true ya que siempre añadimos al final del fichero.
				bw = new BufferedWriter(fw);
				while (!cadena.equals("EOF")) {
					
					cadena = getDataFromKeyboard("Introduzca la cadena a escribir (EOF para terminar):");
					//Aquí necesito coger la cadena para escribirla, pero ¿cómo sin utilizar Scanner?
					
					if (!cadena.equals("EOF"))
						bw.write(cadena+"\n");
				}
				//Importante: Cerrar antes el BufferedWriter que el FileWriter
				bw.close();
				fw.close();
			}
		}
		catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	/**
	 * Dado un string pasado como parámetro, este se muestra en la consola,
	 * y retorna el texto que el usuario introduce por teclado
	 * @param mensaje String que se muestra previamente
	 * @return el texto introducido por el usuario por teclado (entrada estándar)
	 */
	public static String getDataFromKeyboard(String mensaje) {
		String data;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		
		System.out.println(mensaje);
		try {
		data = br.readLine();
		}
		catch(IOException ioe) {
			ioe.printStackTrace();
			data = null;
		}
		return data;
		
	}
	
	
	
	
	
	
	
	/**
	 * Procedimiento que muestra las opciones de menú del programa
	 */
	public static void muestraMenu() {
		System.out.println("======================================================");
		System.out.println("                      Reto UF3                        ");
		System.out.println("======================================================");
		System.out.println("A) Crear fichero ");
		System.out.println("B) Escribir en fichero ");
		System.out.println("C) Salir ");
		System.out.println("======================================================");
		
	}
	
}
