package es.ifp.programacion.uf1.reto;

import java.util.Scanner;


/**
 * Reto: Comprobador de calendarios
 * El usuario introducirá un mes y un día en formato numérico
 * Se mostrará la fecha en modo texto siempre y cuando sea válidad.
 * 
 * Se ha implementado mediante un switch para el mes.
 * Se utiliza una función (implementada también con un switch)
 * que retorna true si el día introducido es válido para el mes
 * false en caso contrario.
 * Si la fecha es válida se muestra la fecha en modo texto.
 * Si es falsa, un mensaje de error.ñ
 * 
 * El programa no implementa ningún bucle para mostrar continuamente
 * la ejecución de la aplicación.
 * 
 * Se implementan también validaciones para que el mes esté comprendido entre 1 y 12
 * Si el mes introducido no es válido, ya no se comprueba el día.
 * 
 * @author juan
 *
 */

public class ProgramaPrincipal {

	public static void main(String[] args) {

		//Declaración de variables
		int dia;
		int mes;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("=======================================");
		System.out.println("       Reto: Validador de fechas");
		System.out.println("=======================================");
		System.out.println("Introduzca un mes en formato numérico:");
		mes = Integer.parseInt(sc.nextLine());
		//Validamos si el mes es correcto. Si es correcto, pedimos el día al usuario. sino, no tiene sentido.
		if (mes>0 && mes < 13) {
			System.out.println("Introduzca un dia en formato numérico:");
			dia = Integer.parseInt(sc.nextLine());
			switch(mes) {
				case 1:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Enero");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 2:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Febrero");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 3:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Marzo");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 4:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Abril");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 5:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Mayo");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 6:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Junio");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 7:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Julio");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 8:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Agosto ");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 9:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Septiembre");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 10:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Octubre");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 11:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Noviembre");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				case 12:
					if (esCorrecta(mes, dia))
						System.out.println("Se ha introducido el día "+dia+ " de Diciembre");
					else
						System.out.println("El día "+dia+" no es válido para este mes.");
					break;
				default:
					break;
				}
		}
		else //Si el mes no está comprendido entre 1 y 12, mensaje de error.
			System.out.println("El mes introducido no es válido");
		
	}
	
	
	/**
	 * Función que comprueba si el día introducido es válido para su mes
	 * @param mes valor entero con el mes
	 * @param dia valor entero con el día
	 * @return true si el día se corresponde con el mes, false sino. Y que sea mayor que cero.
	 */
	public static boolean esCorrecta(int mes, int dia) {
		
		switch(mes) {
			case 1,3,5,7,8,10,12:
				if (dia>0 && dia<=31) 
					return true;
				else 
					return false;
			case 4,6,9,11:
				if (dia>0 && dia<=30) 
					return true;
				else 
					return false;
			case 2:
				if (dia>0 && dia<=28) 
					return true;
				else 
					return false;
			default:
				return false;
		}
	}

}
