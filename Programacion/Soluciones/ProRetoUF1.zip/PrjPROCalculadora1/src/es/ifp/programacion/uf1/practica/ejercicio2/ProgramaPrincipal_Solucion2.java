package es.ifp.programacion.uf1.practica.ejercicio2;


import java.util.Scanner;

/**
 * Ejercicio1 de entreta UF1/UF2
 * Crear una calculadora que realice las operaciones de:
 * Suma
 * Resta
 * Multiplicar
 * Dividir
 * Factorial
 * 
 * Esta solución se ha implementado utilizando if/else anidados
 * 
 * El bucle utilizado es un do-while ya que se van a solicitar datos 
 * continuadamente a los usuarios.
 * 
 * La condición de salida es cuando se pulse 0, 's' o 'S'
 * 
 * Luego el bucle va a ejecutarse cuando la opción no sea ni 0, ni 's', ni 'S'
 * 
 * @Date: 28/02/2023
 * @author juan
 * @Version 1.0
 */


public class ProgramaPrincipal_Solucion2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Declaración de variables
		Scanner sc = new Scanner (System.in);
		String opcion;
		float num1;
		float num2;
		int numInt;
		
		
		do {
		//Entrada de datos
		muestraMenu();
		
		
		System.out.println("Introduzca una opción:");
		opcion = sc.nextLine();
		
		//Transformación de información
		
		if (opcion.equals("1") || opcion.equals("+")) {
			System.out.println("Va a realizar la suma de dos números.");
			System.out.println("Introduzca el primer número:");
			num1 = Float.parseFloat(sc.nextLine());
			System.out.println("Introduzca el segundo número:");
			num2 = Float.parseFloat(sc.nextLine());
			System.out.println("========================================");
			System.out.println("La suma de NUM1 y NUM2 es:"+suma(num1,num2));
			System.out.println("========================================");
		}
		else
			if (opcion.equals("2") || opcion.equals("-")) {
				System.out.println("Va a realizar la resta de dos números.");
				System.out.println("Introduzca el primer número:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo número:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("========================================");
				System.out.println("La resta de NUM1 y NUM2 es:"+resta(num1,num2));
				System.out.println("========================================");
			}
			else
				if (opcion.equals("3") || opcion.equals("*")) {
					System.out.println("Va a realizar la multiplicación de dos números.");
					System.out.println("Introduzca el primer número:");
					num1 = Float.parseFloat(sc.nextLine());
					System.out.println("Introduzca el segundo número:");
					num2 = Float.parseFloat(sc.nextLine());
					System.out.println("========================================");
					System.out.println("La multiplicación de NUM1 y NUM2 es:"+multiplicacion(num1,num2));
					System.out.println("========================================");	
				}
				else
					if (opcion.equals("4") || opcion.equals("/")) {
						System.out.println("Va a realizar la división de dos números.");
						System.out.println("Introduzca el primer número:");
						num1 = Float.parseFloat(sc.nextLine());
						System.out.println("Introduzca el segundo número:");
						num2 = Float.parseFloat(sc.nextLine());
						if (num2==0)
							System.out.println("División por cero. Número no válido.");
						else {
							System.out.println("========================================");
							System.out.println("La división de NUM1 y NUM2 es:"+division(num1,num2));
							System.out.println("========================================");
						}
					}
					else
						if (opcion.equals("5") || opcion.equals("%")) {
							System.out.println("Va a realizar factorial de un númer entero.");
							System.out.println("Introduzca el número entero:");
							numInt = Integer.parseInt(sc.nextLine());
							
							if (numInt==0)
								System.out.println("Error, valor no válido. Introduzca un valor superior a 0");
							else {
								System.out.println("========================================");
								System.out.println("El factorial de "+numInt+" es:"+factorial(numInt));
								System.out.println("========================================");
							}
							
						}
						else
							if (opcion.equals("0") || opcion.equals("s") || opcion.equals("S")) {
								System.out.println("El programa ha finalizado");
							}
							else
								System.out.println("Opción incorrecta");
		}while (!opcion.equals("0") && !opcion.equals("s") && !opcion.equals("S"));
		
	}
	
	
	/**
	 * Definición e implementación de funciones
	 */
	
	
	/**
	 * Procedimiento que muestra las opciones 
	 * de menú en consola.
	 */
	public static void muestraMenu() {
		System.out.println("============ CALCULADORA :: GESTIÓN DE AGUAS, SL ============");
		System.out.println("1. Sumar (+)");
		System.out.println("2. Restar (-)");
		System.out.println("3. Multiplicar (*)");
		System.out.println("4. Dividir (/)");
		System.out.println("5. Factorial (!)");
		System.out.println("0. Salir (S o s)");
	}
	
	/**
	 * Función que realiza la suma de dos números reales
	 * @param num1 Primer número a sumar
	 * @param num2 Segundo número a sumar
	 * @return Un float con la suma de num1 y num2
	 */
	public static float suma(float num1, float num2) {
		return num1 + num2;
	}
	
	/**
	 * Función que realiza la resta de dos números reales
	 * @param num1 primer número a restar
	 * @param num2 segundo número a restar
	 * @return Un float con la resta de num1 y num2
	 */
	public static float resta(float num1, float num2) {
		return num1 - num2;
	}
	
	/**
	 * Función que realiza la multiplicación de dos números reales
	 * @param num1 primer número a multiplicar
	 * @param num2 segundo número float a multiplicar
	 * @return Un float con la multiplicación de num1 y num2
	 */
	public static float multiplicacion(float num1, float num2) {
		return num1 * num2;
	}
	
	/**
	 * Función que realiza la división de dos números reales
	 * @param num1 primer número a dividir
	 * @param num2 segundo número a dividir
	 * @return Un float con la división de num1 y num2
	 */
	public static float division(float num1, float num2) {
		return num1/num2;
	}
	
	
	/**
	 * Función que realiza el factorial de un número entero
	 * @param num entero a calcular su factorial
	 * @return un entero que es el factorial de num
	 */
	public static int factorial(int num) {
		if (num==1)
			return 1;
		else
			return num * factorial (num-1);
		
	}
		

}



