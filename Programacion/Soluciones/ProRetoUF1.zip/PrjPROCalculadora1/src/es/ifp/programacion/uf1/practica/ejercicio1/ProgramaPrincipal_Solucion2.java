package es.ifp.programacion.uf1.practica.ejercicio1;


import java.util.Scanner;

/**
 * Ejercicio1 de entreta UF1/UF2
 * Crear una calculadora que realice las operaciones de:
 * Suma
 * Resta
 * Multiplicar
 * Dividir
 * Resto
 * 
 * Esta solución se ha implementado utilizando if/else anidados
 * 
 * El bucle utilizado es un do-while ya que se van a solicitar datos 
 * continuadamente a los usuarios.
 * 
 * La condición de salida es cuando se pulse 0, 's' o 'S'
 * 
 * Luego el bucle va a ejecutarse cuando la opción no sea ni 0, ni 's', ni 'S'
 * 
 * @Date: 28/02/2023
 * @author juan
 * @Version 1.0
 */


public class ProgramaPrincipal_Solucion2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Declaración de variables
		Scanner sc = new Scanner (System.in);
		String opcion;
		float num1;
		float num2;
		
		
		do {
		//Entrada de datos
		System.out.println("============ CALCULADORA :: GESTIÓN DE AGUAS, SL ============");
		System.out.println("1. Sumar (+)");
		System.out.println("2. Restar (-)");
		System.out.println("3. Multiplicar (*)");
		System.out.println("4. Dividir (/)");
		System.out.println("5. Resto (%)");
		System.out.println("0. Salir (S o s)");
		
		
		System.out.println("Introduzca una opción:");
		opcion = sc.nextLine();
		
		//Transformación de información
		
		if (opcion.equals("1") || opcion.equals("+")) {
			System.out.println("Va a realizar la suma de dos números.");
			System.out.println("Introduzca el primer número:");
			num1 = Float.parseFloat(sc.nextLine());
			System.out.println("Introduzca el segundo número:");
			num2 = Float.parseFloat(sc.nextLine());
			System.out.println("========================================");
			System.out.println("La suma de NUM1 y NUM2 es:"+(num1+num2));
			System.out.println("========================================");
		}
		else
			if (opcion.equals("2") || opcion.equals("-")) {
				System.out.println("Va a realizar la resta de dos números.");
				System.out.println("Introduzca el primer número:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo número:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("========================================");
				System.out.println("La resta de NUM1 y NUM2 es:"+(num1-num2));
				System.out.println("========================================");
			}
			else
				if (opcion.equals("3") || opcion.equals("*")) {
					System.out.println("Va a realizar la multiplicación de dos números.");
					System.out.println("Introduzca el primer número:");
					num1 = Float.parseFloat(sc.nextLine());
					System.out.println("Introduzca el segundo número:");
					num2 = Float.parseFloat(sc.nextLine());
					System.out.println("========================================");
					System.out.println("La multiplicación de NUM1 y NUM2 es:"+(num1*num2));
					System.out.println("========================================");	
				}
				else
					if (opcion.equals("4") || opcion.equals("/")) {
						System.out.println("Va a realizar la división de dos números.");
						System.out.println("Introduzca el primer número:");
						num1 = Float.parseFloat(sc.nextLine());
						System.out.println("Introduzca el segundo número:");
						num2 = Float.parseFloat(sc.nextLine());
						if (num2==0)
							System.out.println("División por cero. Número no válido.");
						else {
							System.out.println("========================================");
							System.out.println("La división de NUM1 y NUM2 es:"+(num1/num2));
							System.out.println("========================================");
						}
					}
					else
						if (opcion.equals("5") || opcion.equals("%")) {
							System.out.println("Va a realizar el resto entre dos números.");
							System.out.println("Introduzca el primer número:");
							num1 = Float.parseFloat(sc.nextLine());
							System.out.println("Introduzca el segundo número:");
							num2 = Float.parseFloat(sc.nextLine());
							System.out.println("========================================");
							System.out.println("El resto entre NUM1 y NUM2 es:"+(num1%num2));
							System.out.println("========================================");
						}
						else
							if (opcion.equals("0") || opcion.equals("s") || opcion.equals("S")) {
								System.out.println("El programa ha finalizado");
							}
							else
								System.out.println("Opción incorrecta");
		}while (!opcion.equals("0") && !opcion.equals("s") && !opcion.equals("S"));
		
	}
		

}



