package es.ifp.programacion.ejercicio.uf5;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Proyecto {
    private String nombre;
    private String descripcion;
    private List<Cliente> clientes;
    private List<JefeProyecto> jefesProyecto;
    public Object id;

    public Proyecto(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.clientes = new ArrayList<>();
        this.jefesProyecto = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public List<JefeProyecto> getJefesProyecto() {
        return jefesProyecto;
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void agregarJefeProyecto(JefeProyecto jefeProyecto) {
        jefesProyecto.add(jefeProyecto);
    }

    public String toString() {
        String proyectoString = "Proyecto: " + nombre + "\n";
        proyectoString += "Descripción: " + descripcion + "\n";
        proyectoString += "Clientes: \n";
        for (Cliente cliente : clientes) {
            proyectoString += cliente.toString() + "\n";
        }
        proyectoString += "Jefes de Proyecto: \n";
        for (JefeProyecto jefeProyecto : jefesProyecto) {
            proyectoString += jefeProyecto.toString() + "\n";
        }
        return proyectoString;
    }
}

/**
 * 
 * Clase que representa a un cliente de la empresa.
 */
class Cliente {

    private String direccion;
    // private String telefono;
    private String descripcion;
    // private String tipoCliente;
    private LocalDate fechaInicio;
    private String jefeProyecto;
    private String cliente;

    private static String id;
    private String nombre;
    private String apellido;

    public Cliente(String id2, String nombre, String apellido) {
        this.id = id2;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    /**
     * Crea un nuevo cliente con los datos indicados.
     * 
     * @param id          el identificador del cliente.
     * @param nombre      el nombre del cliente.
     * @param direccion   la dirección del cliente.
     * @param telefono    el teléfono del cliente.
     * @param fechaInicio la fecha en la que el cliente comenzó a trabajar con la
     *                    empresa.
     */
    public Cliente(String id, String nombre, String direccion, String telefono, LocalDate fechaInicio) {
        Cliente.id = Objects.requireNonNull(id, "El identificador del cliente no puede ser nulo");
        this.nombre = Objects.requireNonNull(nombre, "El nombre del cliente no puede ser nulo");
        this.direccion = Objects.requireNonNull(direccion, "La dirección del cliente no puede ser nula");
        // this.telefono = Objects.requireNonNull(telefono, "El teléfono del cliente no
        // puede ser nulo");
        this.descripcion = Objects.requireNonNull(descripcion, "La descripción del cliente no puede ser nula");
        // this.tipoCliente = Objects.requireNonNull(tipoCliente, "El tipo de cliente no
        // puede ser nulo");
        this.fechaInicio = Objects.requireNonNull(fechaInicio, "La fecha de inicio del cliente no puede ser nula");
        this.jefeProyecto = Objects.requireNonNull(jefeProyecto, "El jefe de proyecto del cliente no puede ser nulo");
    }
    

    /**
     * 
     * Devuelve el identificador del cliente.
     * 
     * @return el identificador del cliente.
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * Devuelve el nombre del cliente.
     * 
     * @return el nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * Establece el nombre del cliente.
     * 
     * @param nombre el nuevo nombre del cliente.
     */
    public void setNombre(String nombre) {
        this.nombre = Objects.requireNonNull(nombre, "El nombre del cliente no puede ser nulo");
    }

    /**
     * 
     * Devuelve la dirección del cliente.
     * 
     * @return la dirección del cliente.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * 
     * Establece la dirección del cliente.
     * 
     * @param direccion la nueva dirección del cliente.
     */
    public void setDireccion(String direccion) {
        this.direccion = Objects.requireNonNull(direccion, "La dirección del cliente no puede ser n");
    }

    /**
     * Devuelve el jefe de proyecto del proyecto.
     *
     * @return el jefe de proyecto del proyecto.
     */
    public JefeProyecto getJefeProyecto() {
        return getJefeProyecto();
    }

    /**
     * Calcula la duración en días del proyecto a partir de la fecha de inicio y la
     * fecha actual.
     * 
     * @return la duración en días del proyecto.
     */
    public int calcularDuracion() {
        LocalDate fechaActual = LocalDate.now();
        return (int) ChronoUnit.DAYS.between(fechaInicio, fechaActual);
    }

    /**
     * Calcula el coste del proyecto en euros a partir del número de horas
     * trabajadas y el coste por hora.
     * 
     * @param numHorasTrabajadas el número de horas trabajadas en el proyecto.
     * @param costeHora          el coste por hora de trabajo.
     * @return el coste total del proyecto.
     */
    public double calcularCoste(int numHorasTrabajadas, double costeHora) {
        return numHorasTrabajadas * costeHora;
    }

    /**
     * Devuelve una cadena con la información del proyecto.
     * 
     * @return una cadena con la información del proyecto.
     */
    @Override
    public String toString() {
        return "Proyecto [id=" + id + ", nombre=" + nombre + ", descripcion=" + descripcion + ", fechaInicio="
                + fechaInicio + ", cliente=" + cliente + ", jefeProyecto=" + jefeProyecto + "]";
    }

    /**
     * Compara este proyecto con otro objeto y determina si son iguales. Dos
     * proyectos se consideran iguales si tienen el mismo identificador.
     * 
     * @param obj el objeto con el que se compara este proyecto.
     * @return true si este proyecto y el objeto son iguales, false en caso
     *         contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Proyecto other = (Proyecto) obj;
        return Objects.equals(id, other.id);
    }

    /**
     * Devuelve un código hash para este proyecto.
     * 
     * @return un código hash para este proyecto.
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

        public static void main(String[] args) {
            Cliente cliente1 = new Cliente(id, "Cliente 1", "12345678A");
            Cliente cliente2 = new Cliente(id, "Cliente 2", "87654321B");
    
            JefeProyecto jefe1 = new JefeProyecto("Jefe 1", "11111111C");
            JefeProyecto jefe2 = new JefeProyecto("Jefe 2", "22222222D");
    
            Proyecto proyecto = new Proyecto("Proyecto 1", "Descripción del Proyecto 1");
            proyecto.agregarCliente(cliente1);
            proyecto.agregarCliente(cliente2);
            proyecto.agregarJefeProyecto(jefe1);
            proyecto.agregarJefeProyecto(jefe2);
    
            System.out.println(proyecto);
        }
    }

