package src.es.ifp.programacion.ejercicio.uf4;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

/**
 * Clase que representa un proyecto informático.
 */

public class Proyecto {

    final String id;
    private String nombre;
    private String descripcion;
    private LocalDate fechaInicio;
    private final Cliente cliente;
    private final JefeProyecto jefeProyecto;

    /**
     * Crea un nuevo proyecto con los datos indicados.
     * 
     * @param id           el identificador del proyecto.
     * @param nombre       el nombre del proyecto.
     * @param descripcion  la descripción del proyecto.
     * @param fechaInicio  la fecha de inicio del proyecto.
     * @param cliente      el cliente para el que se realiza el proyecto.
     * @param jefeProyecto el jefe de proyecto del proyecto.
     */
    public Proyecto(String id, String nombre, String descripcion, LocalDate fechaInicio,
            Cliente cliente, JefeProyecto jefeProyecto) {
        this.id = Objects.requireNonNull(id, "El identificador del proyecto no puede ser nulo");
        this.nombre = Objects.requireNonNull(nombre, "El nombre del proyecto no puede ser nulo");
        this.descripcion = Objects.requireNonNull(descripcion, "La descripción del proyecto no puede ser nula");
        this.fechaInicio = Objects.requireNonNull(fechaInicio, "La fecha de inicio del proyecto no puede ser nula");
        this.cliente = Objects.requireNonNull(cliente, "El cliente del proyecto no puede ser nulo");
        this.jefeProyecto = Objects.requireNonNull(jefeProyecto, "El jefe de proyecto del proyecto no puede ser nulo");
    }

    /**
     * Devuelve el identificador del proyecto.
     * 
     * @return el identificador del proyecto.
     */
    public String getId() {
        return id;
    }

    /**
     * Devuelve el nombre del proyecto.
     * 
     * @return el nombre del proyecto.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del proyecto.
     * 
     * @param nombre el nuevo nombre del proyecto.
     */
    public void setNombre(String nombre) {
        this.nombre = Objects.requireNonNull(nombre, "El nombre del proyecto no puede ser nulo");
    }

    /**
     * Devuelve la descripción del proyecto.
     * 
     * @return la descripción del proyecto.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Establece la descripción del proyecto.
     * 
     * @param descripcion la nueva descripción del proyecto.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = Objects.requireNonNull(descripcion, "La descripción del proyecto no puede ser nula");
    }

    /**
     * Devuelve la fecha de inicio del proyecto.
     * 
     * @return la fecha de inicio del proyecto.
     */
    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    /**
     * Establece la fecha de inicio del proyecto.
     * 
     * @param fechaInicio la nueva fecha de inicio del proyecto.
     */
    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = Objects.requireNonNull(fechaInicio, "La fecha de inicio del proyecto no puede ser nula");
    }

    /**
     * Devuelve el cliente del proyecto.
     * 
     * @return el cliente del proyecto.
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Devuelve
     * la referencia al jefe de proyecto del proyecto.
     *
     * @return la referencia al jefe de proyecto del proyecto.
     */
    public JefeProyecto getJefeProyecto() {
        return jefeProyecto;
    }

    /**
     * Devuelve una cadena de caracteres que representa al proyecto.
     * 
     * @return una cadena que representa al proyecto.
     */
    /**
     * Devuelve la duración del proyecto en días.
     * 
     * @return la duración del proyecto en días.
     */
    public long getDuracion() {
        LocalDate fechaFin = LocalDate.now();
        return ChronoUnit.DAYS.between(fechaInicio, fechaFin);
    }

    /**
     * Muestra la información del proyecto en la consola.
     */
    public String toString() {
        String separador = "\n------------------------------------------------------------\n";
        String str = "Proyecto: " + nombre + separador;
        str += "Id: " + id + "\n";
        str += "Descripción: " + descripcion + "\n";
        str += "Fecha de inicio: " + fechaInicio.toString() + "\n";
        str += "Cliente:\n" + cliente.toString() + "\n";
        str += "Jefe de proyecto:\n" + jefeProyecto.toString() + "\n";
        str += "Duración: " + getDuracion() + " días\n";
        return str;
    }

    /**
     * Compara este proyecto con otro objeto y determina si son iguales.
     * Dos proyectos se consideran iguales si tienen el mismo identificador.
     * 
     * @param obj el objeto a comparar.
     * @return true si los objetos son iguales, false en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Proyecto other = (Proyecto) obj;
        return Objects.equals(id, other.id);
    }

    /**
     * Devuelve un valor hash para el objeto.
     * 
     * @return el valor hash del objeto.
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

/**
 * 
 * Clase que representa a un cliente de la empresa.
 */
class Cliente {
    private final String id;
    private String nombre;
    private String direccion;
    // private String telefono;
    private String descripcion;
    // private String tipoCliente;
    private LocalDate fechaInicio;
    private String jefeProyecto;
    private String cliente;

    /**
     * Crea un nuevo cliente con los datos indicados.
     * 
     * @param id          el identificador del cliente.
     * @param nombre      el nombre del cliente.
     * @param direccion   la dirección del cliente.
     * @param telefono    el teléfono del cliente.
     * @param fechaInicio la fecha en la que el cliente comenzó a trabajar con la
     *                    empresa.
     */
    public Cliente(String id, String nombre, String direccion, String telefono, LocalDate fechaInicio) {
        this.id = Objects.requireNonNull(id, "El identificador del cliente no puede ser nulo");
        this.nombre = Objects.requireNonNull(nombre, "El nombre del cliente no puede ser nulo");
        this.direccion = Objects.requireNonNull(direccion, "La dirección del cliente no puede ser nula");
        // this.telefono = Objects.requireNonNull(telefono, "El teléfono del cliente no
        // puede ser nulo");
        this.descripcion = Objects.requireNonNull(descripcion, "La descripción del cliente no puede ser nula");
        // this.tipoCliente = Objects.requireNonNull(tipoCliente, "El tipo de cliente no
        // puede ser nulo");
        this.fechaInicio = Objects.requireNonNull(fechaInicio, "La fecha de inicio del cliente no puede ser nula");
        this.jefeProyecto = Objects.requireNonNull(jefeProyecto, "El jefe de proyecto del cliente no puede ser nulo");
    }

    /**
     * 
     * Devuelve el identificador del cliente.
     * 
     * @return el identificador del cliente.
     */
    public String getId() {
        return id;
    }

    /**
     * 
     * Devuelve el nombre del cliente.
     * 
     * @return el nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * Establece el nombre del cliente.
     * 
     * @param nombre el nuevo nombre del cliente.
     */
    public void setNombre(String nombre) {
        this.nombre = Objects.requireNonNull(nombre, "El nombre del cliente no puede ser nulo");
    }

    /**
     * 
     * Devuelve la dirección del cliente.
     * 
     * @return la dirección del cliente.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * 
     * Establece la dirección del cliente.
     * 
     * @param direccion la nueva dirección del cliente.
     */
    public void setDireccion(String direccion) {
        this.direccion = Objects.requireNonNull(direccion, "La dirección del cliente no puede ser n");
    }

    /**
     * Devuelve el jefe de proyecto del proyecto.
     *
     * @return el jefe de proyecto del proyecto.
     */
    public JefeProyecto getJefeProyecto() {
        return getJefeProyecto();
    }

    /**
     * Calcula la duración en días del proyecto a partir de la fecha de inicio y la
     * fecha actual.
     * 
     * @return la duración en días del proyecto.
     */
    public int calcularDuracion() {
        LocalDate fechaActual = LocalDate.now();
        return (int) ChronoUnit.DAYS.between(fechaInicio, fechaActual);
    }

    /**
     * Calcula el coste del proyecto en euros a partir del número de horas
     * trabajadas y el coste por hora.
     * 
     * @param numHorasTrabajadas el número de horas trabajadas en el proyecto.
     * @param costeHora          el coste por hora de trabajo.
     * @return el coste total del proyecto.
     */
    public double calcularCoste(int numHorasTrabajadas, double costeHora) {
        return numHorasTrabajadas * costeHora;
    }

    /**
     * Devuelve una cadena con la información del proyecto.
     * 
     * @return una cadena con la información del proyecto.
     */
    @Override
    public String toString() {
        return "Proyecto [id=" + id + ", nombre=" + nombre + ", descripcion=" + descripcion + ", fechaInicio="
                + fechaInicio + ", cliente=" + cliente + ", jefeProyecto=" + jefeProyecto + "]";
    }

    /**
     * Compara este proyecto con otro objeto y determina si son iguales. Dos
     * proyectos se consideran iguales si tienen el mismo identificador.
     * 
     * @param obj el objeto con el que se compara este proyecto.
     * @return true si este proyecto y el objeto son iguales, false en caso
     *         contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Proyecto other = (Proyecto) obj;
        return Objects.equals(id, other.id);
    }

    /**
     * Devuelve un código hash para este proyecto.
     * 
     * @return un código hash para este proyecto.
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public static void main(String[] args) {
        Cliente cliente = new Cliente("1", "Cliente1", "Direccion1", "Descripcion1", LocalDate.of(2022, 4, 7));
        JefeProyecto jefeProyecto = new JefeProyecto("1", "JefeProyecto1", "Apellido1", "Descripcion1",
                LocalDate.of(2022, 4, 7));
        Proyecto proyecto = new Proyecto("1", "Proyecto1", "Descripcion1", LocalDate.of(2022, 4, 7), cliente,
                jefeProyecto);

        System.out.println(proyecto);
    }
}