package src.es.ifp.programacion.ejercicio.uf4;

public class Cliente {
    private String dni;
    public String nombre;
    public String apellidos;
}
