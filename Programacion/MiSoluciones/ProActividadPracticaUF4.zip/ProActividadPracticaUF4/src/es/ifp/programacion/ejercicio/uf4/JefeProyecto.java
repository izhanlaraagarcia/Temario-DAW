package src.es.ifp.programacion.ejercicio.uf4;

import java.time.LocalDate;

public class JefeProyecto {

    public JefeProyecto(String string, String string2, String string3, String string4, LocalDate of) {
    }
//     private String nombre;
//     private String direccion;
//     private String telefono;
//     private String descripcion;
//     private String DNI - ID;
}
