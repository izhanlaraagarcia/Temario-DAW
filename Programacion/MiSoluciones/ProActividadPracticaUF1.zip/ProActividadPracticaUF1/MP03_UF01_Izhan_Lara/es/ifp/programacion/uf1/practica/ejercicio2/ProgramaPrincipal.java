package ejercicio2;

import java.util.Scanner;
import java.util.InputMismatchException;

public class ProgramaPrincipal {
    static Scanner input = new Scanner(System.in);
    static boolean exit = false;

    public static void main(String[] args) {
        double num1, num2, resultado;
        System.out.println("============ CALCULADORA :: GESTIÓN DE AGUAS, SL ============");
        System.out.println(
            "\nIntroduzca una opción del menú:\n1. Sumar (+)\n2. Restar (-)\n3. Multiplicar (*)\n4. Dividir (/)\n5. Resto (%)\n0. Salir (S o s)");
        while (!exit) {
            // System.out.println(
            //         "\nIntroduzca una opción del menú:\n1. Sumar (+)\n2. Restar (-)\n3. Multiplicar (*)\n4. Dividir (/)\n5. Resto (%)\n0. Salir (S o s)");
            String opcion = input.nextLine();
            switch (opcion) {
                case "1":
                case "+":
                // que pruebe esto
                    try {
                        // le pediremos los dos numeros para operar
                        System.out.println("Introduzca el primer número:");
                        num1 = input.nextDouble();
                        System.out.println("Introduzca el segundo número:");
                        num2 = input.nextDouble();
                        // Le diremos que haga la resta desde la clase de la suma
                        resultado = suma(num1, num2);
                        System.out.println("===================================\nLa suma de " + num1 + " y " + num2 + " es " + resultado + "\n===================================");
                    } catch (InputMismatchException e) {
                        // en caso de que lo anterior no sea valido que nos imprima lo siguiente
                        System.out.println("Entrada inválida. Debe ingresar un número.");
                        input.nextLine(); // Limpia el búfer de entrada para evitar un bucle infinito
                    }
                    break;
                case "2":
                case "-":
                    System.out.println("Introduzca el primer número:");
                    try{
                        num1 = input.nextDouble();
                        System.out.println("Introduzca el segundo número:");
                        num2 = input.nextDouble();
                        resultado = resta(num1, num2);
                        System.out.println("===================================\nLa resta de " + num1 + " y " + num2 + " es " + resultado + "\n===================================");
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada inválida. Debe ingresar un número.");
                        input.nextLine();
                    }

                    break;
                    case "3":
                    case "*":
                        try{
                            System.out.println("Introduzca el primer número:");
                        num1 = input.nextDouble();
                        System.out.println("Introduzca el segundo número:");
                        num2 = input.nextDouble();
                        resultado = multiplicacion(num1, num2);
                        System.out.println("===================================\nLa multiplicación de " + num1 + " y " + num2 + " es " + resultado + "\n===================================");
                        } catch (InputMismatchException e) {
                            System.out.println("Entrada inválida. Debe ingresar un número.");
                            input.nextLine();
                        }
                    break;
                case "4":
                case "/":
                    try{

                            System.out.println("Introduzca el primer número:");
                            num1 = input.nextDouble();
                            System.out.println("Introduzca el segundo número:");
                            num2 = input.nextDouble();
                            resultado = division(num1, num2);
                            System.out.println("===================================\nLa divison de " + num1 + " y " + num2 + " es " + resultado + "\n===================================");
                    }catch (InputMismatchException e) {
                        System.out.println("Entrada inválida. Debe ingresar un número.");
                        input.nextLine(); // Limpia el búfer de entrada para evitar un bucle infinito
                    }
                        break;
                    case "5":
                    case "%":
                    try {
                        System.out.println("Introduzca el primer número:");
                    num1 = input.nextDouble();
                    System.out.println("Introduzca el segundo número:");
                    num2 = input.nextDouble();
                    resultado = resto(num1, num2);
                    System.out.println("===================================\nDel resto de " + num1 + " y " + num2 + " es " + resultado + "\n===================================");
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada inválida. Debe ingresar un número.");
                        input.nextLine(); // Limpia el búfer de entrada para evitar un bucle infinito
                    }
                    break;
                case "0":
                case "S":
                case "s":
                    exit = true;
                    System.out.println("El programa ha finalizado");
                    break;
                default:
                    System.out.println("Elige la siguiente operacion o una opcion correcta:");
                    break;
            }
        }
        input.close();
    }

    // bloques para las operaciones
    public static double suma(double num1, double num2) {
        return num1 + num2;
    }

    public static double resta(double num1, double num2) {
        return num1 - num2;
    }

    public static double multiplicacion(double num1, double num2) {
        return num1 * num2;
    }

    public static double division(double num1, double num2) {
        if (num2 <= 0) {
            System.out.println("No se puede dividir entre cero.");
            return 0;
        } else {
            return num1 / num2;
        }
    }

    public static double resto(double num1, double num2) {
        return num1 % num2;
    }
}

/* 
 * @author Izhan Lara Garcia
 */