package es.ifp.programacion.ejercicio.retouf4;

public class PruebaGestorUsuarios {

    public static void main(String[] args) {

        GestorUsuarios gestorUsuarios = new GestorUsuarios();

        gestorUsuarios.darDeAlta("Juan", "Pérez", "12345678A");
        gestorUsuarios.darDeAlta("María", "Gómez", "23456789B", "maria@gmail.com", "123456789");

        Usuario usuario = gestorUsuarios.buscar("12345678A");
        System.out.println(usuario.toString());

        gestorUsuarios.modificar("23456789B", "María", "Gómez", "maria2@gmail.com", "987654321");

        gestorUsuarios.mostrarUsuarios();

    }
}
