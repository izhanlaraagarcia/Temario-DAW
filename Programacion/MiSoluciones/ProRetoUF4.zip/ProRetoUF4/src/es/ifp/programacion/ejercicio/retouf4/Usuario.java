package es.ifp.programacion.ejercicio.retouf4;

public class Usuario {

    private String nombre;
    private String apellidos;
    private String dni;
    private String correoElectronico;
    private String telefono;

    public Usuario(String nombre, String apellidos, String dni) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
    }

    public Usuario(String nombre, String apellidos, String dni, String correoElectronico, String telefono) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.correoElectronico = correoElectronico;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ").append(nombre).append("\n");
        sb.append("Apellidos: ").append(apellidos).append("\n");
        sb.append("DNI: ").append(dni).append("\n");
        sb.append("Correo electrónico: ").append(correoElectronico).append("\n");
        sb.append("Teléfono: ").append(telefono).append("\n");
        return sb.toString();
    }
}
