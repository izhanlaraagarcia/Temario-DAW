package es.ifp.programacion.ejercicio.retouf4;

import java.util.HashMap;
import java.util.Map;

public class GestorUsuarios {

    private Map<String, Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new HashMap<>();
    }

    public void darDeAlta(String nombre, String apellidos, String dni) {
        Usuario usuario = new Usuario(nombre, apellidos, dni);
        usuarios.put(dni, usuario);
    }

    public void darDeAlta(String nombre, String apellidos, String dni, String correoElectronico, String telefono) {
        Usuario usuario = new Usuario(nombre, apellidos, dni, correoElectronico, telefono);
        usuarios.put(dni, usuario);
    }

    public void modificar(String dni, String nombre, String apellidos, String correoElectronico, String telefono) {
        Usuario usuario = usuarios.get(dni);
        usuario.setNombre(nombre);
        usuario.setApellidos(apellidos);
        usuario.setCorreoElectronico(correoElectronico);
        usuario.setTelefono(telefono);
    }

    public Usuario buscar(String dni) {
        return usuarios.get(dni);
    }

    public void mostrarUsuarios() {
        for (Map.Entry<String, Usuario> entry : usuarios.entrySet()) {
            System.out.println("DNI: " + entry.getKey());
            System.out.println(entry.getValue().toString());
        }
    }
}
