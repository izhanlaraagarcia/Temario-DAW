/*
 * @author Izhan Lara Garcia
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class retoUF1 {
    public static void main(String[] args) {
        // Ya que nose puede usar Scanner para los inputs usaremos la funcion
        // BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // crearemos un while para que no salga del programa hasta que se indique
        while (true) {
            System.out.println("Menú:");
            System.out.println("A) Crear fichero");
            System.out.println("B) Escribir en fichero de textos");
            System.out.println("C) Salir");

            try {
                String opcion = br.readLine();
                // Opcion A Crear el archivo
                /*
                 * opción "A", pedimos al usuario la ruta del archivo y comprobamos si el
                 * archivo ya existe utilizando la clase File. Si el archivo no existe,
                 * utilizamos el método createNewFile() para crear un nuevo archivo en la ruta
                 * especificada.
                 */
                if (opcion.equalsIgnoreCase("A")) {
                    System.out.println("Introduce la ruta del fichero:");
                    String ruta = br.readLine();
                    File archivo = new File(ruta);

                    if (archivo.exists()) {
                        System.out.println("El archivo ya existe");
                    } else {
                        archivo.createNewFile();
                        System.out.println("Archivo ha sido creado correctamente");
                    }
                    // Opcion B editar el archivo
                    /*
                     * opción "B", pedimos al usuario la ruta del archivo y comprobamos si el
                     * archivo existe utilizando la clase File. Si el archivo existe, pedimos al
                     * usuario el texto a insertar y utilizamos las clases FileOutputStream y
                     * OutputStreamWriter para escribir el texto en el archivo.
                     */
                } else if (opcion.equalsIgnoreCase("B")) {
                    System.out.println("Introduce la ruta del fichero:");
                    String ruta = br.readLine();
                    File archivo = new File(ruta);

                    if (!archivo.exists()) {
                        System.out.println("El archivo no existe");
                    } else {
                        System.out.println("Introduce el texto a insertar:");
                        String texto = br.readLine();

                        FileOutputStream fos = new FileOutputStream(archivo, true);
                        OutputStreamWriter osw = new OutputStreamWriter(fos);
                        osw.write(texto);
                        osw.write(System.lineSeparator());
                        osw.close();
                        System.out.println("Texto insertado correctamente");
                    }
                    // Opcion C Salir del programa
                } else if (opcion.equalsIgnoreCase("C")) {
                    System.out.println("Saliendo del programa");
                    break;
                } else {
                    System.out.println("Opción inválida");
                }
            } catch (IOException e) {
                System.out.println("Error de entrada/salida");
                e.printStackTrace();
            }
        }

        try {
            br.close();
        } catch (IOException e) {
            System.out.println("Error al cerrar el BufferedReader");
            e.printStackTrace();
        }
    }
}