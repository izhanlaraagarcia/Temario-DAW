
// @author izhan lara garcia
import java.util.Scanner;

public class reto {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        boolean exit = false;
        // byte enero, febero, marzo, abril, mayo, junio, julio, agosto, septiembre,
        // octubre, noviembre, diciembre;

        while (!exit) {
            System.out.println("Escripa el dia del mes:");
            Byte dia = entrada.nextByte();
            System.out.println("Escripa el mes:");
            Byte mes = entrada.nextByte();

            switch (mes) {
                // enero
                case 1:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                // Febero
                case 2:
                    if (dia >= 1 || dia <= 28) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                // Marzo
                case 3:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                // Abril
                case 4:
                    if (dia >= 1 || dia <= 30) {
                        System.out.println("FFecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                // Mayo
                case 5:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                // Junio
                case 6:
                    if (dia >= 1 || dia <= 30) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 7:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 8:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 9:
                    if (dia >= 1 || dia <= 30) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 10:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 11:
                    if (dia >= 1 || dia <= 30) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                case 12:
                    if (dia >= 1 || dia <= 31) {
                        System.out.println("Fecha elegida: dia: " + dia + " del mes: " + dicMeses(mes));

                    } else {
                        System.out.println("Entroduzca una fecha correcta");
                    }
                    break;
                default:
                    System.out.println("Ese mes no es correcto");
                    break;

            }
        }
        entrada.close();
    }

    public static String dicMeses(byte mes) {
        switch (mes) {
            case 1:
                return "Enero";
            case 2:
                return "Febrero";
            case 3:
                return "Marzo";
            case 4:
                return "Abril";
            case 5:
                return "Mayo";
            case 6:
                return "Junio";
            case 7:
                return "Julio";
            case 8:
                return "Agosto";
            case 9:
                return "Septiembre";
            case 10:
                return "Octubre";
            case 11:
                return "Noviembre";
            case 12:
                return "Diciembre";
            default:
                return "";
        }      
    }
}
